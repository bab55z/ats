module.exports = function(Person) {

};
