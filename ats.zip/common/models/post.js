module.exports = function(Post) {

};
